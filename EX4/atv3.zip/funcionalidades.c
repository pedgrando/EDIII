#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

#include "miscelaneous.h"
#include "funcoes_io.h"
#include "data_structures.h"
#include "funcionalidades.h"
#include "funcoes_principais.h"

// FUNCIONALIDADE 11

void funcionalidade11(FILE *file, Cabecalho *header){

}

// FUNCIONALIDADE 12

void funcionalidade12(FILE *file){
	
}

// FUNCIONALIDADE 13

void funcionalidade13(FILE *file){

}

// FUNCIONALIDADE 14

void funcionalidade14(FILE *file){

}





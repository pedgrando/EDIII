#ifndef __FUNCIONALIDADES_H__
#define __FUNCIONALIDADES_H__

#include <stdio.h>
#include <stdlib.h>
#include "data_structures.h"
#include "miscelaneous.h"

//FUNCIONALIDADES

void funcionalidade11(FILE *file, Cabecalho *header);

void funcionalidade12(FILE *file);

void funcionalidade13(FILE *file);

void funcionalidade14(FILE *file);

#endif

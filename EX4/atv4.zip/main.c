// PEDRO ANTONIO BRUNO GRANDO - 12547166 - 100% de contribuição
// PEDRO ARTHUR DO PRADO FRANÇOSO - 12547301 - 100% de contribuição


#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#include "miscelaneous.h"
#include "funcoes_io.h"
#include "data_structures.h"
#include "funcionalidades.h"
#include "funcoes_principais.h"

int main(int argv, char *argc[]){
    int option;
    char arq_entrada[32];

    scanf("%d", &option);		    

    FILE *file_in = NULL;

    Cabecalho *header = malloc(sizeof(Cabecalho));
    *header = ResetaCabecalho();
    
    scanf("%s", arq_entrada);
    if(!(file_in = fopen(arq_entrada, "rb+"))) {    // testa se o arquivo existe            
        PrintErro();
        exit(0);
    }

    header = getHeader(file_in);

    Registro *Register = (Registro*) malloc(sizeof(Registro));
    ListaAdj grafo[header->proxRRN];

    for (int i = 0; i < header->proxRRN; i++) grafo[i].listaAdj = cria_lista();

    switch (option)
    {
    case 11:

	// FUNCIONALIDADE 11

        fseek(file_in, 960, SEEK_SET); // pula o header
        
        while(fread(&Register->removido, sizeof(char), 1, file_in) != 0){
		printf("deu certo\n");

            if(Register->removido == '1'){

                fseek(file_in, 63, SEEK_CUR); // pula registro logicamente removido

            } else {

                ResetaRegistro(Register);

                // le um registro e imprime seu conteudo

                LeRegistroBin(Register, file_in); 

                if(Register->unidadeMedida == 'G') ConverteVelocidade(Register);
                    
                if(!insereLista(grafo[Register->idConecta].listaAdj, *Register)) PrintErro();

                ImprimeRegistro(Register);

            }
        }

        funcionalidade11(file_in, header);

	break;	
    case 12:

	// FUNCIONALIDADE 12

        funcionalidade12(file_in);

	break;	
    case 13:

	// FUNCIONALIDADE 13

        funcionalidade13(file_in);

	break;	
    case 14:

	// FUNCIONALIDADE 14


        funcionalidade14(file_in);

	break;	
    default:
    break;
    }
    free(header);
    fclose(file_in);

}

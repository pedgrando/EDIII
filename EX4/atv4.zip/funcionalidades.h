#ifndef __FUNCIONALIDADES_H__
#define __FUNCIONALIDADES_H__

#include <stdio.h>
#include <stdlib.h>
#include "data_structures.h"
#include "miscelaneous.h"

//FUNCIONALIDADES

int funcionalidade11(FILE *file, Cabecalho *header, Grafo *grafo);

void funcionalidade12(FILE *file, Cabecalho *header, Grafo *grafo);

void funcionalidade13(FILE *file, Cabecalho *header, Grafo *grafo);

void funcionalidade14(FILE *file, Cabecalho *header, Grafo *grafo);

#endif

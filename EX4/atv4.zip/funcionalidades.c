#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

#include "miscelaneous.h"
#include "funcoes_io.h"
#include "data_structures.h"
#include "funcionalidades.h"

// FUNCIONALIDADE 11

void funcionalidade11(FILE *file, Cabecalho *header, ListaAdj *grafo){
    Registro *Register = (Registro*) malloc(sizeof(Registro));

    fseek(file, 960, SEEK_SET); // pula o header
    
    char aux;    
    while(fread(&aux, sizeof(char), 1, file) != 0){


            ResetaRegistro(Register);

            // le um registro e imprime seu conteudo

            LeRegistroBin(Register, file); 

            if(Register->unidadeMedida == 'G') ConverteVelocidade(Register);
            
	    if(grafo[Register->idConecta - 1].idConecta == - 1){    
	    	grafo[Register->idConecta - 1].idConecta = Register->idConecta;
	    	strcpy(grafo[Register->idConecta - 1].nomePoPs, Register->nomePoPs);
	    	strcpy(grafo[Register->idConecta - 1].nomePais, Register->nomePais);
	    	strcpy(grafo[Register->idConecta - 1].siglaPais, Register->siglaPais);
	    }

	    if( Register->idPoPsConectado != -1){
            	if(!insereLista(grafo[Register->idPoPsConectado - 1].listaAdj, Register->idConecta, Register->velocidade, Register->unidadeMedida)){ 
			    PrintErro();
		   	 return;
	    	}
            	if(!insereLista(grafo[Register->idConecta - 1].listaAdj, Register->idPoPsConectado, Register->velocidade, Register->unidadeMedida)){ 
			    PrintErro();
		   	 return;
	    	}

	    	grafo[Register->idPoPsConectado -1].numVerticesAdj++;
	    	grafo[Register->idConecta -1].numVerticesAdj++;
	    }
    }

    for(int i = 0; i < header->proxRRN; i++){
        if(grafo[i].idConecta != -1){
		
		imprimeLista(grafo[i].listaAdj, grafo[i]);
	}
    }
}

// FUNCIONALIDADE 12

void funcionalidade12(FILE *file, Cabecalho *header, ListaAdj *grafo){
	
}

// FUNCIONALIDADE 13

void funcionalidade13(FILE *file, Cabecalho *header, ListaAdj *grafo){

}

// FUNCIONALIDADE 14

void funcionalidade14(FILE *file, Cabecalho *header, ListaAdj *grafo){

}





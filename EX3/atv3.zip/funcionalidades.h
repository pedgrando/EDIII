#ifndef __FUNCIONALIDADES_H__
#define __FUNCIONALIDADES_H__

#include <stdio.h>
#include<stdlib.h>
#include "data_structures.h"
#include "miscelaneous.h"

//FUNCIONALIDADES

void funcionalidade1(FILE *file_in, FILE *file_out, char *arq);

void funcionalidade2(FILE *file);

void funcionalidade3(FILE *file, char *arq);

void funcionalidade4(FILE *file, char *arq);

void funcionalidade5(FILE *file, char *arq);

void funcionalidade6(FILE *file, char *arq);

void funcionalidade7(FILE *file);

void funcionalidade8(FILE *file);

void funcionalidade9(FILE *file, char *arq);

void funcionalidade10(FILE *file);

#endif

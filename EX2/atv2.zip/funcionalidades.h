#ifndef __FUNCIONALIDADES_H__
#define __FUNCIONALIDADES_H__

#include <stdio.h>
#include<stdlib.h>
#include "data_structures.h"
#include "miscelaneous.h"

	//FUNCIONALIDADES

	void funcionalidade1(FILE *file_in, FILE *file_out, Cabecalho *header, char *arq_entrada);

	void funcionalidade2();

	void funcionalidade3(FILE *arq, char *arq_entrada);

	void funcionalidade4(FILE *arq, char *arq_entrada);

void funcionalidade5(FILE *arq, char *arq_entrada);

void funcionalidade6(FILE *arq, char *arq_entrada);



#endif
